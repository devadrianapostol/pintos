# pintos
my homework
